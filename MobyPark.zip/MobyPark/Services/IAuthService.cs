﻿using MobyPark.Models;

namespace MobyPark.Services
{
    public interface IAuthService
    {
        Task<UserReadDto?> RegisterAsync(RegisterRequestDto request);
        Task<TokenResponseDto?> LoginAsync(LoginRequestDto request);
        Task<TokenResponseDto?> RefreshTokensAsync(RefreshTokenRequestDto request);
        Task<bool> LogoutAsync(Guid userId);
    }
}
